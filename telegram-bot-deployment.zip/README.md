# Telegram Payment Bot

A complete Telegram bot for processing digital payments with 24/7 operation on Render.com.

## Features

- Interactive menu system with inline keyboards
- Product catalog: Premium Software ($29.99), Course Bundle ($49.99), VIP Membership ($99.99)
- Service inquiries: Twitter, ChatGPT, YouTube services
- Admin notifications for all purchase requests and service inquiries
- Support for multiple payment methods: Cards, Crypto, RUB

## Bot Commands

- `/start` - Main menu with interactive options
- `/pay` - Browse digital products
- `/services` - Professional service options
- `/help` - Help and support information

## Quick Deploy to Render.com

1. Upload these files to your GitHub repository:
   - `render_bot.py` (main application)
   - `requirements.txt` (dependencies)
   - `render.yaml` (Render configuration)
   - `runtime.txt` (Python version)

2. Connect repository to Render.com
3. Create new "Web Service"
4. Set environment variables:
   ```
   TELEGRAM_BOT_TOKEN = your_bot_token_here
   ADMIN_ID = your_telegram_user_id_here
   ```

5. Deploy and your bot will be online 24/7

## Bot Details

- Uses polling system for reliable message processing
- Flask web server for health checks and monitoring
- Automatic restart capabilities
- Real-time admin notifications
- Comprehensive error handling

## Environment Variables Required

- `TELEGRAM_BOT_TOKEN` - Your Telegram bot token from BotFather
- `ADMIN_ID` - Your Telegram user ID for admin notifications
- `PORT` - Server port (automatically set by Render to 10000)

## Support

Bot processes all commands instantly and sends admin notifications for:
- New user registrations
- Product purchase requests with customer details
- Service inquiries with contact information
- Deployment status updates